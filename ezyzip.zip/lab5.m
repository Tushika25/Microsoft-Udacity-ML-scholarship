clear all
close all
clc

% part a

omega_n = 5;
zeta = 2/5;

b = omega_n^2;
a = [1 2*zeta*omega_n omega_n^2];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y,'k');
hold on

y;
t;
rise_time = 0;
peak_time = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time = t(k); 
        break
    end
end
rise_time
for i= 1:length(y)
    if y(i) == max(y)
        peak_time = t(i);        
    end
end
peak_time

percentOvershoot = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time = c(m); 
        break
    end
end
settling_time

% part b

Mp_1 = exp(-zeta*pi/sqrt(1-zeta^2));

k= (-log(0.5*Mp_1)/pi)^2 ;
zeta_new = sqrt(k/(1+k))

b = omega_n^2;
a = [1 2*zeta_new*omega_n omega_n^2];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y,'k');
hold on

rise_time1 = 0;
peak_time1 = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time1 = t(k); 
        break
    end
end
rise_time1
for i= 1:length(y)
    if y(i) == max(y)
        peak_time1 = t(i);        
    end
end
peak_time1

percentOvershoot1 = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time1 = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time1 = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time1 = c(m); 
        break
    end
end
settling_time1


% part c for poles

b = 5000;
a = [1 204 825 5000];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y);
hold on

rise_time_1 = 0;
peak_time_1 = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time_1 = t(k); 
        break
    end
end
rise_time_1
for i= 1:length(y)
    if y(i) == max(y)
        peak_time_1 = t(i);        
    end
end
peak_time_1

percentOvershoot_1 = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time_1 = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time_1 = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time_1 = c(m); 
        break
    end
end
settling_time_1


b = 500;
a = [1 24 105 500];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y);
hold on

rise_time_2 = 0;
peak_time_2 = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time_2 = t(k); 
        break
    end
end
rise_time_2
for i= 1:length(y)
    if y(i) == max(y)
        peak_time_2 = t(i);        
    end
end
peak_time_2

percentOvershoot_2 = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time_2 = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time_2 = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time_2 = c(m); 
        break
    end
end
settling_time_2

legend('pole at -200', 'pole at -20', 'Location', 'Southeast')

% part c for zeroes

b = [25 5000];
a = [200 800 5000];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y);
hold on

rise_time_1 = 0;
peak_time_1 = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time_1 = t(k); 
        break
    end
end
rise_time_1
for i= 1:length(y)
    if y(i) == max(y)
        peak_time_1 = t(i);        
    end
end
peak_time_1

percentOvershoot_1 = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time_1 = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time_1 = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time_1 = c(m); 
        break
    end
end
settling_time_1


b = [25 500];
a = [20 80 500];
sys = tf(b,a);
[y,t]= step(sys, 5);
plot(t, y);
hold on

rise_time_2 = 0;
peak_time_2 = 0;
for k= 1:length(y)
    if y(k) >= 1
        rise_time_2 = t(k); 
        break
    end
end
rise_time_2
for i= 1:length(y)
    if y(i) == max(y)
        peak_time_2 = t(i);        
    end
end
peak_time_2

percentOvershoot_2 = (max(y) - 1) * 100
b = flip(y);
c = flip(t);
settling_time_2 = 0;
for m= 1:length(b)
    if b(m) <= 0.98
        settling_time_2 = c(m); 
        break
    end
    if b(m) >= 1.02
        settling_time_2 = c(m); 
        break
    end
end
settling_time_2


legend('zero at -200', 'zero at -20', 'Location', 'Southeast')